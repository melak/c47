To change the firmware on a DM42, use the following instructions.
*Warning:* this is a very early version of the C47 program for DM42
so use it at your own risk.

## Updating the DMCP Firmware

The C47 firmware requires a recent version of the DMCP firmware. If
you have never updated this for your calculator (or have not updated
this recently) then this should be updated first.

1. Start your computer. Take a DM42 and turn it on; then
   - if you are using DM42 firmware:
     press [Setup] [5] (System) [2] (Enter system menu)
     [4] (Reset to DMCP menu)
   - if you are using a previous version of C47 firmware:
     press [fMODE] [fSYSTEM]
   - Now connect your computer to the calculator micro-USB socket
     using a suitable data cable. Ensure it connects properly on the
     calculator side – cutting back the plastic edge a bit may be
     necessary.
   - Press [6] (Activate USB Disk). The flash disk of your DM42 should
     show up as an external mass storage volume on your computer now.
2. Start the internet browser on your computer and go to 
   [the SwissMicros firmware website](https://technical.swissmicros.com/dm42/firmware/).
   - Download the most recent file within the `DMCP` directory (this should be named DMCP_flash_n.nn.bin") and
     copy this to the DM42 flash disk.
3. 'Eject' the USB disk from the operating system, and do not press
   [EXIT] on the calculator as instructed. Pressing [EXIT] will
   sometimes cause loss of data on the DM42 USB disk.
4. The DMCP firmware will automatically detect the update. Press
   [ENTER] to continue upgrading the DMCP.
5. After a few seconds the firmware will be complete. Press [EXIT]
   to continue.

## Convert a DM42 to a C47

1. Start your computer. Take a DM42 and turn it on; then
   - press [Setup] [5] (System) [2] (Enter system menu)
     [4] (Reset to DMCP menu)
   - Now connect your computer to the calculator micro-USB socket
     using a suitable data cable. Ensure it connects properly on the
     calculator side – cutting back the cable socket's plastic edge a 
     bit may be necessary.
   - Press [6] (Activate USB Disk). The flash disk of your DM42 should
     show up as an external mass storage volume on your computer now.
2. Download the
   [latest release](https://47calc.com) of C47 for DM42.
   - Copy the files `C47.pgm` and `C47_qspi.bin` to the DM42
     flash disk.
   - Option: Copying `testPgms.bin` to the DM42 flash disk will give
     you some test programs pre-entered.
   - Option: If your donor calculator is a WP43, you will need to load the 
     original DM42 keymap file. Rename the file `original_DM42_keymap.bin`
     to `keymap.bin` and copy it to the DM42 flash disk. This will restore all keys to 
     match the C47 internal layout and allow you to choose the WP43 profile from the calculator's KEYS menu later.
   - Delete any other files ending `_qspi.bin` or `.pgm` because the
     calculator may attempt to load those instead of the C47 firmware.
3. 'Eject' the USB disk from the operating system, and do not press
   [EXIT] on the calculator as instructed. Pressing [EXIT] will
   sometimes cause loss of data on the DM42 USB disk.
4. Press [4] (Load QSPI from FAT). This will automatically detect the
   relevant file and flash it to the DM42. It should be completed in
   seconds.
   - Press any key to restart followed by [EXIT] [3] (DMCP Menu).
5. Should your calculator crash or not respond at this point, it will
   be due to the incompatibility of the (new) qspi file to the (old) 
   firmware pgm file. The solution to recover to the DMCP menu is to press
   F1 while you use a pin to press the rear RESET button. Then, proceed as below.
6. Press [3] (Load Program) and select `C47.pgm`. Wait about 15s for
   flashing to complete and follow on screen instructions to reboot if needed.


See [the download page](https://47calc.com)
for further details on how to order a key template or produce a custom overlay and stickers to
make it easier to use your C47 calculator.

## Update C47 to the latest version

1. Start your computer. Take a DM42 and turn it on; then
   - press [fMODE] [fSYSTEM]
   - Now connect your computer to the calculator micro-USB socket
     using a suitable data cable. Ensure it connects properly on the
     calculator side – cutting back the plastic edge a bit may be
     necessary.
   - Press [6] (Activate USB Disk). The flash disk of your DM42 should
     show up as an external mass storage volume on your computer now.
2. Download the
   [latest release](https://47calc.com) of C47 for DM42.
   - Copy the files `C47.pgm` and `C47_qspi.bin` to the DM42
     flash disk.
   - Option: Copying `testPgms.bin` to the DM42 flash disk will give
     you some test programs pre-entered.
   - Option: If your donor calculator is a WP43, you will need to load the 
     original DM42 keymap file. Rename the file `original_DM42_keymap.bin`
     to `keymap.bin` and copy it to the DM42 flash disk. This will restore all keys to 
     match the C47 internal layout and allow you to choose the WP 43S profile from the calculator's KEYS menu later.
   - Delete any other files ending `_qspi.bin` or `.pgm` because the
     calculator may attempt to load those instead of the WP43 firmware.
3. 'Eject' the USB disk from the operating system, and do not press
   [EXIT] on the calculator as instructed. Pressing [EXIT] will
   sometimes cause loss of data on the DM42 USB disk.
4. Press [4] (Load QSPI from FAT). This will automatically detect the
   relevant file and flash it to the DM42. It should be completed in
   seconds.
   - Press any key to restart followed by [EXIT] [3] (DMCP Menu).
5. Should your calculator crash or not respond at this point, it will
   be due to the incompatibility of the (new) qspi file to the (old) 
   firmware pgm file. The solution to recover to the DMCP menu is to press
   F1 while you use a pin to press the rear RESET button. Then, proceed as below.
6. Press [3] (Load Program) and select `C47.pgm`. Wait about 15s for
   flashing to complete and follow on screen instructions to reboot if needed.

## Converting a DM42 calculator running C47 back to a DM42

1. Start your computer. Take the DM42 calculator running C47 and turn it on; then
   - press [gMODE] [gSYSTEM]
   - Now connect your computer to the calculator micro-USB socket
     using a suitable data cable. Ensure it connects properly on the
     calculator side – cutting back the plastic edge a bit may be
     necessary.
   - Press [6] (Activate USB Disk). The flash disk of your DM42 should
     show up as an external mass storage volume on your computer now.
2. Start the internet browser on your computer and go to 
   [the SwissMicros firmware website](https://technical.swissmicros.com/dm42/firmware/).
   - Download the most recent file beginning `DM42` and ending `.pgm`
     in that directory.
   - Download the most recent file in the `qspi_data` subdirectory
     beginning `DM42_qspi` and ending `.bin`.
   - Copy these both to the DM42 flash disk.
   - Delete any other files ending `_qspi.bin` or `.pgm` because the
     calculator may attempt to load those instead of the DM42 firmware.
3. 'Eject' the USB disk from the operating system, and do not press
   [EXIT] on the calculator as instructed. Pressing [EXIT] will
   sometimes cause loss of data on the DM42 USB disk.
4. Press [4] (Load QSPI from FAT). This will automatically detect the
   relevant file and flash it to the DM42. It should be completed in
   seconds.
   - Press any key to restart followed by [EXIT] [3] (DMCP Menu).
5. Should your calculator crash or not respond at this point, it will
   be due to the incompatibility of the (new) qspi file to the (old) 
   firmware pgm file. The solution to recover to the DMCP menu is to press
   F1 while you use a pin to press the rear RESET button. Then, proceed as below.
6. Press [3] (Load Program) and select `DM42_n.nn.pgm`. Wait about 15s for
   flashing to complete and follow on screen instructions to reboot if needed.
