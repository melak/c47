C43 uses GTK3+ and you must install the latest GTK3+ libraries if you do not already have them.
Download and install the latest release of the
[gtk3-runtime (not gtk2-runtime)](https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer/releases).

You should also install (or re-install) the `C43__StandardFont.ttf` font.

C43 preserves state between runs using a file called `backup.bin`. When updating to a newer
version of C43, this backup file is unlikely to work. In most cases the simulator will detect
this incompatibility and delete the file. If the simulator crashes as soon as you try and run
it, you should delete the `backup.bin` file and try again.

If you want to preserve your calculator state when updating to a newer version, try saving the
state using `SAVE` and restore it using `LOAD`. Details can be found in the manuals.

To run the calculator simulator, run `c43.exe` from the directory it is unpacked into.

---

Procedure to link the C43 simulator to the Windows CALC key on the keyboard:

Create a folder on a easy to access place, i.e. C:\C43
Copy all required simulator files there, which are at the time of writing:

c43.exe
res/*.* (including C43__StandardFont.ttf, dm42l_L1.png, c43_pre.css and more)

c43.cmd
c43.cmd.txt (this file)
c43.reg

Edit the c43.cmd file to contain reference to the correct folder, default being c:\C43\c43.exe
Edit the c43.reg file to refer to the correct folder, default being c:\C43
Double click the C43.reg file and confirm adding to the registry.

Now, the Calc key on the Windows keyboard should call the batch file c43.cmd, which in turn should start the c43.exe simulator.

